#include <iostream>
using namespace std;
struct Node {
    int day;
    double rainfall;
    Node* next;
    Node* prev;
    Node(int d, double r) {
        day = d;
        rainfall = r;
        next = NULL;
        prev = NULL;
    }
};
class RainfallList {
private:
    Node* head;
    Node* tail;

public:
    RainfallList() {
        head = NULL;
        tail = NULL;
    }

    
    void addRainfall(int day, double rainfall) {
        Node* newNode = new Node(day, rainfall);
        if (head == NULL) {
            head = tail = newNode;
        } else {
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
    } 
    double totalRainfall() {
        double total = 0;
        Node* temp = head;
        while (temp != NULL) {
            total += temp->rainfall;
            temp = temp->next;
        }
        return total;
    }

    void findMinMaxRainfall() {
        if (head == NULL) {
            cout << "No data available.\n";
            return;
        }

        Node* temp = head;
        double maxRain = temp->rainfall, minRain = temp->rainfall;
        int maxDay = temp->day, minDay = temp->day;

        while (temp != NULL) {
            if (temp->rainfall > maxRain) {
                maxRain = temp->rainfall;
                maxDay = temp->day;
            }
            if (temp->rainfall < minRain) {
                minRain = temp->rainfall;
                minDay = temp->day;
            }
            temp = temp->next;
        }

        cout << "Highest Rainfall: " << maxRain << " on Day " << maxDay << "\n";
        cout << "Lowest Rainfall: " << minRain << " on Day " << minDay << "\n";
    }
    void rainfallAfter5thDay() {
        Node* temp = head;
        for (int i = 0; i < 5 && temp != NULL; i++) {
            temp = temp->next;
        }
        if (temp != NULL && temp->next != NULL) {
            cout << "Rainfall on day after 5th node: " << temp->next->rainfall << " mm\n";
        } else {
            cout << "No data available after the 5th day.\n";
        }
    }
    void displayRainfall() {
        Node* temp = head;
        while (temp != NULL) {
            cout << "Day " << temp->day << ": " << temp->rainfall << " mm\n";
            temp = temp->next;
        }
    }
//Deconstructor
    ~RainfallList() {
        Node* temp;
        while (head) {
            temp = head;
            head = head->next;
            delete temp;
        }
    }
};
int main() {
    RainfallList rainfallData;
    double rain;
    cout << "Enter total rainfall for 7 days:\n";
    for (int i = 1; i <= 7; i++) {
        do {
            cout << "Day " << i << ": ";
            cin >> rain;
            if (rain < 0) {
                cout << "Invalid input! Rainfall cannot be negative.\n";
            }
        } while (rain < 0);

        rainfallData.addRainfall(i, rain);
    }
    cout << "\nRainfall Data:\n";
    rainfallData.displayRainfall();
    double total = rainfallData.totalRainfall();
    cout << "\nTotal Rainfall for the week: " << total << " mm\n";
    cout << "Average Weekly Rainfall: " << total / 7 << " mm\n";
    rainfallData.findMinMaxRainfall();
    rainfallData.rainfallAfter5thDay();
    return 0;
}
