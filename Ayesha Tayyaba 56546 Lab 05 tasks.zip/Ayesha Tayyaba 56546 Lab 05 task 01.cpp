#include <iostream>
using namespace std;
struct Node {
    int data;
    Node* prev;
    Node* next;

    Node(int val) {
        data = val;
        prev = NULL;
        next = NULL;
    }
};
class DoublyLinkedList {
private:
    Node* head;
public:
    DoublyLinkedList() {
        head = NULL;
    }
    void createList(int n) {
        for (int i = 0; i < n; i++) {
            int value;
            cout << "Enter value " << i + 1 << ": ";
            cin >> value;
            addEnd(value);
        }
    }
    void addEnd(int value) {
        Node* newNode = new Node(value);
        if (!head) {
            head = newNode;
            return;
        }
        Node* temp = head;
        while (temp->next)
            temp = temp->next;
        temp->next = newNode;
        newNode->prev = temp;
    }
    void addBeginning(int value) {
        Node* newNode = new Node(value);
        if (!head) {
            head = newNode;
            return;
        }
        newNode->next = head;
        head->prev = newNode;
        head = newNode;
    }
    void addAfterValue(int target, int value) {
        Node* temp = head;
        while (temp && temp->data != target)
            temp = temp->next;
        if (!temp) {
            cout << "Value " << target << " not found.\n";
            return;
        }
        Node* newNode = new Node(value);
        newNode->next = temp->next;
        newNode->prev = temp;
        if (temp->next)
            temp->next->prev = newNode;
        temp->next = newNode;
    }
    void display() {
        Node* temp = head;
        cout << "Doubly Linked List: ";
        while (temp) {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }
};
int main() {
    DoublyLinkedList dll;
    int n, value;
    cout << "Enter number of nodes: ";
    cin >> n;
    dll.createList(n);
    dll.display();
    cout << "Enter value to insert at beginning: ";
    cin >> value;
    dll.addBeginning(value);
    dll.display();
    cout << "Enter value to insert after 45: ";
    cin >> value;
    dll.addAfterValue(45, value);
    dll.display();
    return 0;
}

